package types

type GeneralHeader struct {
	Authorization string `header:"Authorization"`
}
