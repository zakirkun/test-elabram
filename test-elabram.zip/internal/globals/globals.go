package globals

import "github.com/zakirkun/test-elabram/internal/pkg/database"

var DB *database.DBModel
